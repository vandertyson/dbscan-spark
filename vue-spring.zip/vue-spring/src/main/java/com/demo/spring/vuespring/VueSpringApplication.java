package com.demo.spring.vuespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VueSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(VueSpringApplication.class, args);
	}

}

